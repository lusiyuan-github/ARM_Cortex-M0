#include "code_def.h"
#include <stdint.h>
#include <stdio.h>

float Fre = 100.0;        //ѡ̨Ƶ��

int		Gain_Reduction = 10;//����˥��


int main()
{ 
	//interrupt initial
	NVIC_CTRL_ADDR = 0x1FFF;      //ʹ��IRQ0 ~ IRQ12
	
  TIME_Init();
	
	//Flash initial
	SPI_Initializes();
	SFLASH_WAKEUP();							//���绽��
	
	
	QN8027_Init();

	MSi001_Init();
	
//	delay_ms(200);
	
//	mem_tunnel();									//��ʾ�Ѵ�Ƶ��

	while(1)
	{	
		Key_Scan();
	}

}

