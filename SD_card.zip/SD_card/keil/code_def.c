#include "mpuiic.h"
#include <string.h>
#include <stdio.h>
#include "code_def.h"

extern float Fre;

extern int	 Gain_Reduction;

char Up = 0;

char pointer = 1;		//��ָ̨��	

char frame1[17] = {0x76, 0x61, 0x31, 0x31, 0x2E, 0x76, 0x61, 0x6C, 0x3D, 0x30, 0x30, 0x30, 0x30, 0xff, 0xff, 0xff, 0x00};

char frame2[16] = {0x63, 0x68, 0x6f, 0x6f, 0x73, 0x65, 0x2e, 0x76, 0x61, 0x6c, 0x3d, 0x31, 0xff, 0xff, 0xff, 0x00};

char frame3[15] = {0x72, 0x61, 0x62, 0x69, 0x74, 0x2e, 0x76, 0x61, 0x6c, 0x3d, 0x31, 0xff, 0xff, 0xff, 0x00};				//rabit.val=1

char frame4[13] = {0x76, 0x61, 0x34, 0x2e, 0x76, 0x61, 0x6c, 0x3d, 0x30, 0xff, 0xff, 0xff, 0x00};	

uint8_t Flag_1   = 0;                  //����ɹ���־λ
uint8_t	finger   = 0;									 //��ָ
uint8_t BUF      = 0;                  //����BUF

uint8_t Flag_2   = 0; 
uint8_t Order    = 0;
uint8_t integer  = 0;
uint8_t fraction = 0;

int test = 0;

const uint32_t FLASH_BASE = 511 * 4096;

char	rhythm_mark, frequency_mark;

typedef union 
{
	uint8_t flash_data[4];
	int			f;
}UnData;

UnData sendData,count,showData;

void delay_us(int us)
{
	uint32_t temp;
	SysTick->LOAD  = us*25;
	SysTick->VALUE = 0x00;      //��ռ�����
	SysTick->CTRL  = 0x05;      //ʹ�� ���ж� ���ô�����ʱ��
	do
	{
		temp = SysTick->CTRL;
	}while((temp&0x01)&&!(temp&(1<<16)));
	SysTick->CTRL  = 0x00;      //�رռ�����
	SysTick->VALUE = 0x00;			//��ռ�����
}

void delay_ms(int ms)					//ms ȡֵ��Χ 1 ~ 1398
{
	uint32_t temp;
	SysTick->LOAD  = ms*25000;
	SysTick->VALUE = 0x00;      //��ռ�����
	SysTick->CTRL  = 0x05;      //ʹ�� ���ж� ���ô�����ʱ��
	do
	{
		temp = SysTick->CTRL;
	}while((temp&0x01)&&!(temp&(1<<16)));
	SysTick->CTRL  = 0x00;      //�رռ�����
	SysTick->VALUE = 0x00;			//��ռ�����
}

void Serial_Send_Data1(int num, int fre)   //��̨Ƶ����ʾ
{
	frame1[2]  = (char)(num / 10) + '0'; 
	frame1[3]  = (char)(num % 10) + '0';                 
	
	frame1[9]  = fre / 1000 + '0';
	frame1[10]  = (fre / 100) % 10 + '0';
	frame1[11] = (fre / 10 ) % 10 + '0';
	frame1[12] = fre % 10 + '0';
	
  UART1String(frame1); 
}


void KEY0Handle(void)					//�洢��̨
{
	count.f++;				//������̨����
		
	SFLASH_WriteNByte(count.flash_data, (FLASH_BASE + 0), 4);   //�ӵ�ַ0������д��4�ֽ�����		
	
	SFLASH_WriteNByte(sendData.flash_data, (FLASH_BASE + count.f * 4), 4);

	Serial_Send_Data1(count.f, sendData.f);
	
	LED->LED_MODE = 3;
}

void KEY1Handle(void)					//��յ�̨
{
	count.f = 0;
	
	SFLASH_WriteNByte(count.flash_data, (FLASH_BASE + 0), 4);   //�ӵ�ַ0������д��4�ֽ�����	
	
	pointer = 1;			//ָ���λ
	
	UART1String("clear.val=1\xff\xff\xff");
	
	LED->LED_MODE = 3;	
}

void KEY2Handle(void)					//¼��
{
	SPEAK->Recording_mode = ~SPEAK->Recording_mode;
	
	if(SPEAK->Recording_mode == 1)
	{
		if(TIMER->ENABLE == 0)	//¼�Ƶ�̨
		{
			UART1String("PG.val=4\xff\xff\xff");			
			delay_ms(200);
			UART1String("clear.val=1\xff\xff\xff");
			delay_ms(10);	
			UART1String("record_en.en=1\xff\xff\xff");			
		}
		else										//¼��K��
		{
			UART1String("PG_.val=5\xff\xff\xff");		
			delay_ms(80);
			UART1String("clear.val=1\xff\xff\xff");
			delay_ms(10);	
			UART1String("record_en.en=1\xff\xff\xff");	
		}
	}
	else
	{
		UART1String("record_en.en=0\xff\xff\xff");		
	}
	
	LED->LED_MODE = 3;
}

void KEY3Handle(void)					//¼������	
{
	SPEAK->Recording_play_mode = ~SPEAK->Recording_play_mode;
	
	if(SPEAK->Recording_play_mode == 1)
	{
		if(TIMER->ENABLE == 0)	//���ŵ�̨
		{
			UART1String("play_en.en=1\xff\xff\xff");
		}
		else										//����K��
		{
			SPEAK->Mode = 0;
			UART1String("play_en.en=1\xff\xff\xff");
		}
	}
	
	else
	{
		if(TIMER->ENABLE == 0)	//�ص���̨
		{
			UART1String("play_en.en=0\xff\xff\xff");
		}
		else										//�ص�K��
		{
			SPEAK->Mode = 1;
			UART1String("play_en.en=0\xff\xff\xff");
		}
	}

	LED->LED_MODE = 3;	
}

void KEY4Handle(void)						//K��ģʽ
{
	TIMER->ENABLE = ~TIMER->ENABLE;				//��ʱ��
	
	if(TIMER->ENABLE == 0)
	{
		SD_stop();
		SD->play = 0;					//�ر�SD������
		
		SPEAK->Mode = 0;			//�ر���ͨ��

		UART1String("PG.val=1\xff\xff\xff");
		
		SPEAK->Recording_type = 0;	//¼�Ƶ�̨
		
		SFLASH_ReadNByte(sendData.flash_data, (FLASH_BASE + 4), 4);  //MSi001	
		fre_select();
		
	  mem_tunnel();			
	}
	
	else if(TIMER->ENABLE == 1)
	{
		SPEAK->Mode = 1;			//������ͨ��
		
		SD->play = 1;					//����SD������
		
		SPEAK->Recording_type = 1;	//¼�� ���� + ����

		UART1String("PG.val=5\xff\xff\xff");		
	}
	
	LED->LED_MODE = 3;
}

void KEY5Handle(void)						//FM��Ϸ
{
	GAME->Game = ~GAME->Game;
	
	if(GAME->Game == 0)
	{
		SPEAK->Mode = 0;		//�ر���ͨ��
		
		MPU_Write_Byte(0x00,0x11);  								  //QN8027
		
		UART1String("PG.val=1\xff\xff\xff");
		
		SFLASH_ReadNByte(sendData.flash_data, (FLASH_BASE + 4), 4);  //MSi001	
		fre_select();	

	  mem_tunnel();		
	}

	else 
	{
		SPEAK->Mode = 1;		//������ͨ��
		
		MPU_Write_Byte(0x00,0x31);   
	
		MSi_SPI_Write(0x203E82);

		UART1String("PG.val=6\xff\xff\xff");			
	}
	
	LED->LED_MODE = 3;
}

void KEY6Handle(void)							//��е�۲���
{
//	SD->play = ~SD->play;				//���� or ��ͣ
//	Stereo->turn_on = SD->play;
	UART1String("PG.val=8\xff\xff\xff");
}

void KEY7Handle(void)							//����������	
{
	Stereo->turn_on = 0;				//FM��Ϸ3
	GAME->Game 	    = 1;				
	GAME->GAME_type = 3;				
	
	SPEAK->Mode = 1;						//��ͨ��

	MPU_Write_Byte(0x00,0x31);	//������	
	
	GAME->Number_emit = 1;			//����
	
	test++;
	
	delay_ms(1000);
	SD->play = ~SD->play;				//���� or ��ͣ
	Stereo->turn_on = SD->play;
	
	if(test == 1)
	{
		delay_ms(500);
		delay_ms(500);	
		delay_ms(500);		
		delay_ms(200);
		SD_stop();
	}
	
	MPU_Write_Byte(0x00,0x39);	//����
	
	UART1String("PG.val=7\xff\xff\xff");
	
	LED->LED_MODE = 3;
}
/*
void KEY7Handle(void)							//����������
{
	MPU_Write_Byte(0x00,0x31);	//������
	
	SD->play = ~SD->play;
	Stereo->turn_on = SD->play;
}*/

/********����1*********/
char ReadUART1State()
{
    char state;
	state = UART1 -> UARTTX_STATE;
    return(state);
}

char ReadUART1()
{
    char data;
	data = UART1 -> UARTRX_DATA;
    return(data);
}

void WriteUART1(char data)
{
    while(ReadUART1State());
	UART1 -> UARTTX_DATA = data;
}

void UART1String(char *stri)
{
	int i;
	for(i=0;i<strlen(stri);i++)
	{
		WriteUART1(stri[i]);
	}
}

void UART1Handle()
{
	uint8_t temp;
	
	temp = ReadUART1();

	Serial1_Receive_Data(temp);
	
	if(Flag_1 == 1)											//���ݽ��ճɹ�
	{
		Flag_1 = 0;												//��ձ�־λ
		
		GAME->Number_emit = BUF;
	}
}


/*  ������������ͬ ��Ҫ���ĵĵط���ע�ˡ�   */

void Serial1_Receive_Data(char data)    
{
	int i = 0;
	static uint8_t openmv[6];	       //��ȡ���ݡ�
	static uint8_t state = 0;	
	static uint8_t bit_number = 0;
	
	
	if(state == 0&&data == 0x2C)
	{
		state = 1;
		openmv[bit_number++] = data;
	}
	
	else if(state == 1&&data == 18)
	{
		state = 2;
		openmv[bit_number++] = data;
	}
	
	else if(state == 2)
	{
		openmv[bit_number++] = data;
		
		if(bit_number == 5)          //׼������β֡��
		{  
			state=3;
		}
	}

	
	else if(state == 3 && data == 0x5B)		         //����Ƿ���ܵ�������־
	{
    state   = 0;
		Flag_1  = 1;                //���ճɹ��ı�־λ
		
		bit_number = 0;
		
		GAME->GAME_type   = openmv[2];
		GAME->Finger_emit = openmv[3]; 
		
		BUF    						= openmv[4];

    for(i=0; i<6; i++)        //��
    {
      openmv[i] = 0x00;
    } 
  }
	
	else
	{
		state = 0;
		bit_number=0;
		
    for(i=0; i<6; i++)          //��
    {
      openmv[i] = 0x00;
    }

	}
}


/********����2*********/
char ReadUART2State()
{
    char state;
	state = UART2 -> UARTTX_STATE;
    return(state);
}

char ReadUART2()
{
    char data;
	data = UART2 -> UARTRX_DATA;
    return(data);
}

void WriteUART2(char data)
{
    while(ReadUART2State());
	UART2 -> UARTTX_DATA = data;
}

void UART2String(char *stri)
{
	int i;
	for(i=0;i<strlen(stri);i++)
	{
		WriteUART2(stri[i]);
	}
}

void UART2Handle()
{
	uint8_t temp;
	
	temp = ReadUART2();

	Serial2_Receive_Data(temp);
	
	if(Flag_2 == 1)											//���ݽ��ճɹ�
	{
		Flag_2 = 0;												//��ձ�־λ
		
		switch(Order)
		{
			case 2 : Auto_Search(); break;
			case 3 : tune_left();   break;
			case 4 : tune_right();  break;
			case 7 : sendData.f = integer * 10 + fraction; fre_select(); break;
			default: break;
		}
	}
}


/*  ������������ͬ ��Ҫ���ĵĵط���ע�ˡ�   */

void Serial2_Receive_Data(uint8_t data)    
{
	int i = 0;
	static uint8_t openmv[17];	       //��ȡ���ݡ�
	static uint8_t state = 0;	
	static uint8_t bit_number = 0;
	
	if(state == 0&&data == 0xA5)
	{
		state = 1;
		openmv[bit_number++] = data;
	}
	
	else if(state == 1&&data == 0xFC)
	{
		state = 2;
		openmv[bit_number++] = data;
	}
	
	else if(state == 2)
	{
		openmv[bit_number++] = data;
		
		if(bit_number == 16)          //׼������β֡��
		{  
			state=3;
		}
	}

	
	else if(state == 3 && data == 0xFB)		         //����Ƿ���ܵ�������־
	{
    state  = 0;
		Flag_2 = 1;                //���ճɹ��ı�־λ
		
		bit_number = 0;
		
		Order    = openmv[7];
		integer  = openmv[9];
		fraction = openmv[8];
		
    for(i=0; i<17; i++)        //��
    {
      openmv[i] = 0x00;
    } 
  }
	
	else
	{
		state = 0;
		bit_number=0;
		
    for(i=0; i<17; i++)          //��
    {
      openmv[i] = 0x00;
    }

	}
}


void  Key_Scan()
{
	MKEY->ROW = 0x00;           //�������
	if(MKEY->COL != 0x0F)
	{
		delay_ms(1);            //����
	
	  if(MKEY->COL != 0x0F)     //��������
		{
			MKEY->ROW = 0x07;       //0111  Row3
			switch(MKEY->COL)
			{
				case 0x07: sendData.f = sendData.f - 1; fre_select();	LED->LED_MODE = 1; break;
				case 0x0B: sendData.f = sendData.f + 1; fre_select();	LED->LED_MODE = 2; break;
				case 0x0D: Gain_Reduction = Gain_Reduction + 1; gain_select(); break;
				case 0x0E: Gain_Reduction = Gain_Reduction - 1; gain_select(); break;
			}
			
			MKEY->ROW = 0x0B;       //1011  Row2
			switch(MKEY->COL)
			{
				case 0x07: sendData.f = sendData.f - 2; fre_select(); AUTO->enable = 1; Up = 0;	LED->LED_MODE = 1; break;	//������һ����̨
				case 0x0B: sendData.f = sendData.f + 1; fre_select(); AUTO->enable = 1; Up = 1;	LED->LED_MODE = 2; break;	//������һ����̨
				case 0x0D: tune_left();  break;
				case 0x0E: tune_right(); break;
			}

			MKEY->ROW = 0x0D;       //1101  Row1
			switch(MKEY->COL)
			{
				case 0x07: SD_last();    break;
				case 0x0B: SD_next();    break;
				case 0x0D: SD_stop();    break;
				case 0x0E: SD->play = 1; break;
			}
/*
			MKEY->ROW = 0x0E;       //1110  Row0
			switch(MKEY->COL)
			{
				case 0x07: Number = 13; break;
				case 0x0B: Number = 14; break;
				case 0x0D: Number = 15; break;
				case 0x0E: Number = 16; break;
			}
*/			
			MKEY->ROW = 0x00;       	//���ּ��
			while(MKEY->COL != 0x0F);
		}
	}
	
}

void fre_select()
{
	int 	INT;
	float F_SYNTH;
	int 	FRAC;
	int 	commend;
	
	int dis_0,dis_1,dis_2,dis_3;
	
	Fre = sendData.f / 10.0;     //�õ���ʵƵ��
	
	F_SYNTH = Fre * 32.0;
	
	INT = F_SYNTH / 96;
	
	FRAC = (float)(F_SYNTH/96.0 - INT) * 3000;
	
	commend = INT << 16 | FRAC << 4 | 2;
	
	MSi_SPI_Write(commend);
	
	dis_0 = sendData.f % 10;						//С��λ
	
	dis_3 = Fre / 100;       						//��λ
	dis_2 = (int)(Fre / 10) % 10;				//ʮλ
	dis_1 = (int)Fre % 10;							//��λ

	SEG->DATA = dis_3 << 12 | dis_2 << 8 | dis_1 << 4 | dis_0;
}

void gain_select()
{
	int commend;
	
	commend = 0xC << 12 | Gain_Reduction << 4 | 1;
	
	MSi_SPI_Write(commend);
}

void TIME_Init()        //T = 1s
{
	TIMER->LOAD   = 25000000;
	TIMER->ENABLE = 0;
}	

void TIMEHandle()				
{
	rhythm_mark	   = Score->rhythm_mark;
	frequency_mark = Score->frequency_mark;
	
	printf("rhythm.val=%d\xff\xff\xff", rhythm_mark);
	delay_ms(10);
	printf("frequency.val=%d\xff\xff\xff", frequency_mark);	
}


void MSi001_Init()
{
	MSi_SPI_Write(0x043420);    //Reg0
	MSi_SPI_Write(0x00C0A1);    //Reg1
	
//	MSi_SPI_Write(0x213202);  	//Reg2 INT FRAC
	
  SFLASH_ReadNByte(sendData.flash_data, (FLASH_BASE + 4), 4);    //�ӵ�ַ4����������4�ֽ�����	
	fre_select();
	
	MSi_SPI_Write(0x00FA03);		//Reg3
	MSi_SPI_Write(0x28BB85);		//Reg5
	MSi_SPI_Write(0x200016);		//Reg6
	
	UART1String("PG.val=1\xff\xff\xff");	
}

void MSi_SPI_Write(uint32_t Data)
{
	uint8_t i;
	
	MSi001->MSi_SPI_CS  = 0;
	MSi001->MSi_SPI_CLK = 0;
	
	Data = Data << 8;
	
	for(i = 0; i < 24; i++)
	{
		if(Data & 0x80000000)
			MSi001->MSi_SPI_DATA = 1;
		else
			MSi001->MSi_SPI_DATA = 0;
		
		delay_us(1);
		MSi001->MSi_SPI_CLK = 0;
		
		delay_us(1);
		MSi001->MSi_SPI_CLK = 1;
		
		delay_us(1);
		Data <<= 1;
	}
	
	MSi001->MSi_SPI_CS  = 1;
	MSi001->MSi_SPI_CLK = 0;
	delay_us(1);

}

void QN8027_Init()
{
  MPU_Write_Byte(0x00,0x11);   //SYSTEM
	MPU_Write_Byte(0x01,0x18);   //CH1
	MPU_Write_Byte(0x02,0xB9);	 //CPLT
	MPU_Write_Byte(0x03,0x80);	 //REG_XTL
	MPU_Write_Byte(0x04,0xB2);	 //REG_VGA
	MPU_Write_Byte(0x10,0x4B);	 //PAC
	MPU_Write_Byte(0x11,0x81);	 //FDEV	
//	sendData.f = 998;
//	SFLASH_WriteNByte(sendData.flash_data, (FLASH_BASE + 4), 4);   //�ӵ�ַ0������д��4�ֽ�����	
}


uint8_t MPU_Write_Byte(uint8_t reg,uint8_t data) 				 
{ 
  MPU_IIC_Start(); 
	MPU_IIC_Send_Byte((MPU_ADDR<<1)|0);//����������ַ+д����
	if(MPU_IIC_Wait_Ack())	//�ȴ�Ӧ��
	{
		MPU_IIC_Stop();	
		return 1;		
	}

  MPU_IIC_Send_Byte(reg);	//д�Ĵ�����ַ
  MPU_IIC_Wait_Ack();		  //�ȴ�Ӧ��

	MPU_IIC_Send_Byte(data);//��������
	if(MPU_IIC_Wait_Ack())	//�ȴ�ACK
	{
		MPU_IIC_Stop();	 
		return 1;		 
	}		 
    MPU_IIC_Stop();	 
	return 0;
}

void ResearchHandle()
{
	
	AUTO->enable = 0;	//������� �ѹر�ʹ��
	
	if(AUTO->result == 0)					//���ǵ�̨	
	{
		if(Up == 0)					//��������(����)
		{
			sendData.f = sendData.f - 1;
			fre_select(); 
			AUTO->enable = 1;		
		}
		else								//��������(����)
		{
			sendData.f = sendData.f + 1;
			fre_select(); 
			AUTO->enable = 1;		
		}
	}
	else if(AUTO->result == 1)		//�ǵ�̨
	{
		sendData.f = sendData.f + 1;
		fre_select(); 		
	}
	else if(AUTO->result == 2)		//δ�ɹ��ж�
	{
		AUTO->enable = 1;		//�����ж�
	}

}

/************************************************
�������� �� SPI_Initializes
��    �� �� SPI��ʼ��
��    �� �� ��
�� �� ֵ �� ��
*************************************************/
void SPI_Initializes(void)
{
  W25Q16->SPI_CS 	 = 0;
  W25Q16->SPI_CLK  = 1;
  W25Q16->SPI_MOSI = 1;
}

/************************************************
�������� �� SPI_WriteByte
��    �� �� SPIдһ�ֽ�����
��    �� �� TxData --- ���͵��ֽ�����
�� �� ֵ �� ��
*************************************************/
void SPI_WriteByte(char TxData)
{
  uint8_t cnt;

  for(cnt=0; cnt<8; cnt++)
  {
    W25Q16->SPI_CLK = 0;                         //ʱ�� - ��
    delay_us(1);

    if(TxData & 0x80)                            //��������
      W25Q16->SPI_MOSI = 1;
    else
      W25Q16->SPI_MOSI = 0;
    TxData <<= 1;

    delay_us(1);
    W25Q16->SPI_CLK = 1;                         //ʱ�� - ��
		delay_us(1);
  }
}

/************************************************
�������� �� SPI_ReadByte
��    �� �� SPI��һ�ֽ�����
��    �� �� ��
�� �� ֵ �� ���������ֽ�����
*************************************************/
char SPI_ReadByte(void)
{
  uint8_t cnt;
  uint8_t RxData = 0;

  for(cnt=0; cnt<8; cnt++)
  {
    W25Q16->SPI_CLK = 0;                            //ʱ�� - ��
    delay_us(1);

    RxData <<= 1;
    if(W25Q16->SPI_MISO)                            //��ȡ����
    {
      RxData |= 0x01;
    }

    W25Q16->SPI_CLK = 1;                            //ʱ�� - ��
    delay_us(1);
  }

  return RxData;
}

void Serial_Send_Data2(char data)		//�л�Ƶ��
{
	frame2[11] = data + '0';
	
  UART1String(frame2); 
}

void tune_left()
{
	if(pointer > 1)
	{
		pointer--;			//����
		
		SFLASH_ReadNByte(sendData.flash_data, (FLASH_BASE + pointer * 4), 4);

		fre_select();		//����
		
		Serial_Send_Data2(pointer);
	}
}

void tune_right()
{
	if(pointer < count.f)
	{
		pointer++;			//����
		
		SFLASH_ReadNByte(sendData.flash_data, (FLASH_BASE + pointer * 4), 4);

		fre_select();		//����
		
		Serial_Send_Data2(pointer);
	}
}

void SD_next()
{
	SD->next = 1;
	SD->next = 0;
	
  UART1String("next.val=1\xff\xff\xff"); 	
}

void SD_last()
{
	SD->last = 1;
	SD->last = 0;
	
  UART1String("before.val=1\xff\xff\xff"); 
}

void SD_stop()
{
	SD->stop = 1;
	SD->stop = 0;
}

void mem_tunnel()
{
	char i;
	
	int show_data;
	
	SFLASH_ReadNByte(count.flash_data, (FLASH_BASE + 0), 4);				//������̨����	
	
	for(i = 1; i <= count.f; i++)										//��ʾ�洢Ƶ��
	{
		SFLASH_ReadNByte(showData.flash_data, (FLASH_BASE + i*4), 4);				//������̨Ƶ��
		
		Serial_Send_Data1(i, showData.f);											//��ʾ����Ļ��
	}
}

void Serial_Send_Data3(char data)		//������
{
	frame3[10] = data + '0';
	
  UART1String(frame3); 
}


void Serial_Send_Data4()		//����ָ
{
	char i;
	
	i = GAME->Number_recv;
	
	if(i == 10)
		i = 0;
	
	frame4[2] = GAME->Finger_recv + '0';
	
	frame4[8] = i + '0';
	
  UART1String(frame4); 
}


void GAME1Handle()
{
	uint8_t number;
	
	number = GAME->Number_recv;
	
	if(GAME->GAME_type == 1)
		Serial_Send_Data3(number);
	else if(GAME->GAME_type == 2)
		Serial_Send_Data4();			
}

void Auto_Search(void)
{
	sendData.f = 870;
	fre_select();
	
	while(sendData.f < 1080)
	{
		sendData.f ++;
		fre_select();
		delay_ms(20);
	}
	
	mem_tunnel();	
}
