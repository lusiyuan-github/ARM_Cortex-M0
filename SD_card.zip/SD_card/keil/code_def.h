#ifndef __code_def_H__
#define __code_def_H__

#include <stdint.h>
#include "sflash.h"

//INTERRUPT DEF
#define NVIC_CTRL_ADDR (*(volatile unsigned *)0xe000e100)

//SysTick DEF
typedef struct{
    volatile uint32_t CTRL;
    volatile uint32_t LOAD;
    volatile uint32_t VALUE;
    volatile uint32_t CALIB;
}SysTickType;

#define SysTick_BASE 0xe000e010
#define SysTick ((SysTickType *)SysTick_BASE)


//LED DEF
typedef struct{
    volatile uint32_t LED_MODE;
}LEDType;

#define LED_BASE 0x40000000
#define LED ((LEDType *)LED_BASE)

//UART DEF
typedef struct{
    volatile uint32_t UARTRX_DATA;
    volatile uint32_t UARTTX_STATE;
    volatile uint32_t UARTTX_DATA;
}UARTType;

#define UART_BASE 0x40010000
#define UART1 ((UARTType *)UART_BASE)


//Matrix_Key DEF
typedef struct{
    volatile uint32_t ROW;
    volatile uint32_t COL;
}MKEYType;

#define MKEY_BASE 0x40020000
#define MKEY ((MKEYType *)MKEY_BASE)


//SEG DEF
typedef struct{
    volatile uint32_t DATA;
}SEGType;

#define SEG_BASE 0x40030000
#define SEG ((SEGType *)SEG_BASE)


//TIME DEF
typedef struct{
    volatile uint32_t LOAD;
    volatile uint32_t ENABLE;
    volatile uint32_t VALUE;
}TIMERType;

#define TIMER_BASE 0x40040000
#define TIMER ((TIMERType *)TIMER_BASE)


//MSi001 DEF
typedef struct{
    volatile uint32_t MSi_SPI_CS;
    volatile uint32_t MSi_SPI_CLK;
    volatile uint32_t MSi_SPI_DATA;
}MSi001Type;

#define MSi001_BASE 0x40050000
#define MSi001 ((MSi001Type *)MSi001_BASE)


//QN8027 DEF
typedef struct{
    volatile uint32_t QN_IIC_SCL;
    volatile uint32_t QN_IIC_SDA;
    volatile uint32_t ACK;
}QN8027Type;

#define QN8027_BASE 0x40060000
#define QN8027 ((QN8027Type *)QN8027_BASE)

#define MPU_ADDR		0X2C


//AUTO_Research DEF
typedef struct{
    volatile uint32_t enable;
    volatile uint32_t result;
}AUTOType;

#define AUTO_BASE 0x40070000
#define AUTO ((AUTOType *)AUTO_BASE)


//W25Q16 DEF
typedef struct{
    volatile uint32_t SPI_CS;
    volatile uint32_t SPI_CLK;
    volatile uint32_t SPI_MOSI;
    volatile uint32_t SPI_MISO;	
}W25Q16Type;

#define W25Q16_BASE 0x40080000
#define W25Q16 ((W25Q16Type *)W25Q16_BASE)


//SPEAK DEF
typedef struct{
    volatile uint32_t Mode;	
	volatile uint32_t Recording_mode;
	volatile uint32_t Recording_play_mode;
	volatile uint32_t Recording_type;
}SPEAKType;

#define SPEAK_BASE 0x40090000
#define SPEAK ((SPEAKType *)SPEAK_BASE)


//Buzzer DEF
typedef struct{
    volatile uint32_t EN;
}BuzzerType;

#define Buzzer_BASE 0x400A0000
#define Buzzer ((BuzzerType *)Buzzer_BASE)



//SD DEF
typedef struct{
    volatile uint32_t play;
    volatile uint32_t next;
    volatile uint32_t last;
    volatile uint32_t stop;
}SDType;

#define SD_BASE 0x400B0000
#define SD ((SDType *)SD_BASE)


//GAME1 DEF
typedef struct{
    volatile uint32_t Game;	
    volatile uint32_t GAME_type;
    volatile uint32_t Finger_emit;
	  volatile uint32_t Finger_recv;
    volatile uint32_t Number_emit;
    volatile uint32_t Number_recv;
}GAMEType;

#define GAME_BASE 0x400C0000
#define GAME ((GAMEType *)GAME_BASE)

//Score DEF
typedef struct{
    volatile uint32_t rhythm_mark;	
    volatile uint32_t frequency_mark;
}ScoreType;

#define Score_BASE 0x400D0000
#define Score ((ScoreType *)Score_BASE)


//Stereo DEF
typedef struct{
    volatile uint32_t turn_on;	
}StereoType;

#define Stereo_BASE 0x400E0000
#define Stereo ((StereoType *)Stereo_BASE)



//UART2 DEF
typedef struct{
    volatile uint32_t UARTRX_DATA;
    volatile uint32_t UARTTX_STATE;
    volatile uint32_t UARTTX_DATA;
}UART2Type;

#define UART2_BASE 0x400F0000
#define UART2 ((UART2Type *)UART2_BASE)


void delay_us(int us);
void delay_ms(int ms);

void KEY0Handle(void);
void KEY1Handle(void);
void KEY2Handle(void);
void KEY3Handle(void);
void KEY4Handle(void);
void KEY5Handle(void);
void KEY6Handle(void);
void KEY7Handle(void);

char ReadUART1State(void);
char ReadUART1(void);
void WriteUART1(char data);
void UART1String(char *stri);
void UART1Handle(void);
void Serial1_Receive_Data(char data);

char ReadUART2State(void);
char ReadUART2(void);
void WriteUART2(char data);
void UART2String(char *stri);
void UART2Handle(void);
void Serial2_Receive_Data(uint8_t data);

void Key_Scan(void);

void fre_select(void);
void gain_select(void);

void TIME_Init(void);
void TIMEHandle(void);

void MSi001_Init(void);
void MSi_SPI_Write(uint32_t Data);

void QN8027_Init(void);
//uint8_t MPU_Write_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf);//IIC����д
//uint8_t MPU_Read_Len(uint8_t addr,uint8_t reg,uint8_t len,uint8_t *buf); //IIC������ 
uint8_t MPU_Write_Byte(uint8_t reg,uint8_t data);				//IICдһ���ֽ�
//uint8_t MPU_Read_Byte(uint8_t reg);						//IIC��һ���ֽ�

void ResearchHandle(void);

void SPI_Initializes(void);
void SPI_WriteByte(char TxData);
char SPI_ReadByte(void);

void tune_left(void);
void tune_right(void);

void SD_next(void);
void SD_last(void);
void SD_stop(void);

void Serial_Send_Data1(int num, int fre);
void Serial_Send_Data2(char data);
void Serial_Send_Data3(char data);
void Serial_Send_Data4(void);
void mem_tunnel(void);

void GAME1Handle(void);

void Auto_Search(void);

#endif